import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';


class RenderPage extends StatefulWidget {
  const RenderPage({super.key});

  @override
  State<RenderPage> createState() => _RenderPageState();

}

class _RenderPageState  extends State<RenderPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        
      ),
    );
  }
}